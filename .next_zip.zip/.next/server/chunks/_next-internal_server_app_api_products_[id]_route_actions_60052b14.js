module.exports=[55833,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_route_actions_60052b14.js.map