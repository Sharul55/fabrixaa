module.exports=[14007,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_route_actions_850cb780.js.map