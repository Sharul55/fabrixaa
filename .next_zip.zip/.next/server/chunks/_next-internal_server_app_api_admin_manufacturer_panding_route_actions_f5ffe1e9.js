module.exports=[980,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_manufacturer_panding_route_actions_f5ffe1e9.js.map