module.exports=[93026,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_manufacturer_%5Bid%5D_route_actions_148f9cc5.js.map