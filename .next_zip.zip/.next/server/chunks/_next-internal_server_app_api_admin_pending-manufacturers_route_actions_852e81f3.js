module.exports=[87284,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_pending-manufacturers_route_actions_852e81f3.js.map