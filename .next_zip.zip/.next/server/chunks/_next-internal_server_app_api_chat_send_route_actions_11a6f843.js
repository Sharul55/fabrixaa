module.exports=[57322,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_chat_send_route_actions_11a6f843.js.map