module.exports=[96331,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_auth_register_route_actions_3564e727.js.map