module.exports=[43201,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_socket_route_actions_4dd9c19f.js.map