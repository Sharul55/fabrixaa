module.exports=[72498,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_orders_%5Bid%5D_approve_route_actions_1d959be1.js.map