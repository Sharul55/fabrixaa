module.exports=[85442,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_admin_manufacturers_%5Bid%5D_route_actions_2ea5ebb5.js.map