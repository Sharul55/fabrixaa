module.exports=[877,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_stats_route_actions_05832952.js.map