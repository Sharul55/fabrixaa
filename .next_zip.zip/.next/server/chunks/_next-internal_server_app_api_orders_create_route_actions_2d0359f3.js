module.exports=[13387,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_orders_create_route_actions_2d0359f3.js.map