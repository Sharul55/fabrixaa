module.exports=[78587,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_admin_manufacturers_pending_route_actions_d2b4a15b.js.map