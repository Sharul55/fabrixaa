module.exports=[45084,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_route_actions_ef3ab472.js.map