module.exports=[7485,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_manufacturer_dashboard_page_actions_e1de2b6f.js.map