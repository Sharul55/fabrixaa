module.exports=[20710,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_admin_dashboard_page_actions_b058c280.js.map