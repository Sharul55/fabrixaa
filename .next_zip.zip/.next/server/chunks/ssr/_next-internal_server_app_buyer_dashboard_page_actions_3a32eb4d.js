module.exports=[38033,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_buyer_dashboard_page_actions_3a32eb4d.js.map