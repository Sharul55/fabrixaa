module.exports=[87453,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_buyer_orders_page_actions_b88df13c.js.map