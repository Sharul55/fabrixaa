var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/admin/manufacturers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c2d01995._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_admin_manufacturers_[id]_route_actions_2ea5ebb5.js")
R.m(98082)
module.exports=R.m(98082).exports
