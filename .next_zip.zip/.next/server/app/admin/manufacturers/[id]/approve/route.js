var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/admin/manufacturers/[id]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__4d930f53._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/ce889_server_app_admin_manufacturers_[id]_approve_route_actions_2d2d5c7a.js")
R.m(9306)
module.exports=R.m(9306).exports
