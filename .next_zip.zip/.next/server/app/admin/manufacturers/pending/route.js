var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/admin/manufacturers/pending/route.js")
R.c("server/chunks/[root-of-the-server]__20308570._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_admin_manufacturers_pending_route_actions_d2b4a15b.js")
R.m(70298)
module.exports=R.m(70298).exports
