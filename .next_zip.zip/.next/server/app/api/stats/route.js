var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/route.js")
R.c("server/chunks/[root-of-the-server]__f9ba0d64._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_stats_route_actions_505045c5.js")
R.m(380)
module.exports=R.m(380).exports
