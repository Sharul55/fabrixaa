var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/pending-manufacturers/route.js")
R.c("server/chunks/[root-of-the-server]__a9a54913._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_pending-manufacturers_route_actions_852e81f3.js")
R.m(2618)
module.exports=R.m(2618).exports
