var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/manufacturer/panding/route.js")
R.c("server/chunks/[root-of-the-server]__0e4b3dc8._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_manufacturer_panding_route_actions_f5ffe1e9.js")
R.m(59903)
module.exports=R.m(59903).exports
