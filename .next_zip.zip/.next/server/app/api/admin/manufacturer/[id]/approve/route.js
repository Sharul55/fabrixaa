var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/manufacturer/[id]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__afea8af7._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/ce889_server_app_api_admin_manufacturer_[id]_approve_route_actions_cd237f09.js")
R.m(23082)
module.exports=R.m(23082).exports
