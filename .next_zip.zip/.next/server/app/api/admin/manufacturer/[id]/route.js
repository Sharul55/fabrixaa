var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/manufacturer/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__df59d68c._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_manufacturer_[id]_route_actions_148f9cc5.js")
R.m(94221)
module.exports=R.m(94221).exports
