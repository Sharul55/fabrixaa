var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__c478932d._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_5060e774._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_9a81c53e.js")
R.m(36298)
module.exports=R.m(36298).exports
