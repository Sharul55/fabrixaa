var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/socket/route.js")
R.c("server/chunks/[root-of-the-server]__c4759ef5._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__f7b8a4a7._.js")
R.c("server/chunks/[root-of-the-server]__9a106767._.js")
R.c("server/chunks/_next-internal_server_app_api_socket_route_actions_4dd9c19f.js")
R.m(20788)
module.exports=R.m(20788).exports
