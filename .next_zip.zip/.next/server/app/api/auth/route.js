var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/route.js")
R.c("server/chunks/[root-of-the-server]__aeb26725._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_route_actions_693293fe.js")
R.m(97334)
module.exports=R.m(97334).exports
