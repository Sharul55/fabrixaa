var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signup/route.js")
R.c("server/chunks/[root-of-the-server]__494c1ee0._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_5060e774._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signup_route_actions_3cc2654d.js")
R.m(51448)
module.exports=R.m(51448).exports
