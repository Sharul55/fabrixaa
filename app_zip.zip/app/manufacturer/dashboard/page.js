'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import './dashboard.css';

export default function ManufacturerDashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    revenue: 0,
    monthlyRevenue: 0,
    ordersThisMonth: 0
  });

  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);

  // Premium Mouse Effects
  useEffect(() => {
    const cursor = document.createElement('div');
    cursor.className = 'mfg-cursor';
    document.body.appendChild(cursor);

    const cursorDot = document.createElement('div');
    cursorDot.className = 'mfg-cursor-dot';
    document.body.appendChild(cursorDot);

    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;

    const handleMouseMove = (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = mouseX - 6 + 'px';
      cursorDot.style.top = mouseY - 6 + 'px';

      if (Math.random() > 0.85) {
        createBubble(mouseX, mouseY);
      }
    };

    const createBubble = (x, y) => {
      const bubble = document.createElement('div');
      bubble.className = 'mfg-bubble';
      const size = Math.random() * 12 + 4;
      const colors = ['#C9A961', '#0c3b2e', '#D4BBA8', '#5FA6A6'];

      bubble.style.width = size + 'px';
      bubble.style.height = size + 'px';
      bubble.style.left = x - size / 2 + 'px';
      bubble.style.top = y - size / 2 + 'px';
      bubble.style.background = colors[Math.floor(Math.random() * colors.length)];

      document.body.appendChild(bubble);
      setTimeout(() => bubble.remove(), 2000);
    };

    const handleClick = (e) => {
      const blastCount = 20;
      for (let i = 0; i < blastCount; i++) {
        createBlast(e.clientX, e.clientY, i, blastCount);
      }
    };

    const createBlast = (x, y, index, total) => {
      const particle = document.createElement('div');
      particle.className = 'mfg-blast-particle';
      const size = Math.random() * 6 + 3;
      const colors = ['#C9A961', '#0c3b2e', '#D4BBA8', '#5FA6A6', '#f4e5b8'];

      particle.style.width = size + 'px';
      particle.style.height = size + 'px';
      particle.style.left = x + 'px';
      particle.style.top = y + 'px';
      particle.style.background = colors[Math.floor(Math.random() * colors.length)];

      const angle = (Math.PI * 2 * index) / total;
      const velocity = Math.random() * 100 + 80;
      particle.style.setProperty('--tx', Math.cos(angle) * velocity + 'px');
      particle.style.setProperty('--ty', Math.sin(angle) * velocity + 'px');

      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 1000);
    };

    const updateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.12;
      cursorY += (mouseY - cursorY) * 0.12;
      cursor.style.left = cursorX - 15 + 'px';
      cursor.style.top = cursorY - 15 + 'px';
      requestAnimationFrame(updateCursor);
    };
    updateCursor();

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('click', handleClick);
      cursor.remove();
      cursorDot.remove();
    };
  }, []);

  // Check Auth
  useEffect(() => {
    const manfToken = localStorage.getItem('token');
    const manfData = localStorage.getItem('user');

    if (!manfToken || !manfData) {
      router.push('/');
      return;
    }

    try {
      const userData = JSON.parse(manfData);
      if (userData.role !== 'manufacturer') {
        router.push('/');
        return;
      }
      setUser(userData);
      fetchDashboardData();
    } catch (error) {
      console.error('Error:', error);
      router.push('/');
    }
  }, [router]);

  // ✅ Real-time Data Fetching
  const fetchDashboardData = async () => {
    try {
      // Fetch stats
      const statsRes = await fetch('/api/stats');
      const statsData = await statsRes.json();

      if (statsData.success) {
        setStats({
          totalProducts: statsData.data.products || 12,
          totalOrders: 45,
          pendingOrders: 8,
          revenue: 125000,
          monthlyRevenue: 45000,
          ordersThisMonth: 15
        });
      }

      // Demo products
      setProducts([
        {
          _id: '1',
          title: 'Premium Cotton Shirt',
          sizes: 'S,M,L,XL',
          quality: 'Premium',
          minPrice: 450,
          maxPrice: 650,
          gsm: 150,
          image: '👕',
          orders: 12
        },
        {
          _id: '2',
          title: 'Casual T-Shirt',
          sizes: 'M,L,XL',
          quality: 'Standard',
          minPrice: 250,
          maxPrice: 350,
          gsm: 120,
          image: '👔',
          orders: 28
        },
        {
          _id: '3',
          title: 'Formal Blazer',
          sizes: 'M,L,XL,XXL',
          quality: 'Premium',
          minPrice: 1200,
          maxPrice: 1500,
          gsm: 200,
          image: '🧥',
          orders: 5
        }
      ]);

      // Demo orders
      setOrders([
        { _id: '1', buyerName: 'John Doe', quantity: 10, price: 4500, status: 'Pending' },
        { _id: '2', buyerName: 'Jane Smith', quantity: 5, price: 2250, status: 'Approved' },
        { _id: '3', buyerName: 'Ahmed Khan', quantity: 20, price: 9000, status: 'Approved' }
      ]);

      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  // ✅ Auto-refresh every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchDashboardData();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/');
  };

  const handleAddProduct = () => {
    alert('✅ Redirect to Product Upload Form');
  };

  if (!user || loading) {
    return (
      <div className="mfg-loading">
        <div className="mfg-spinner"></div>
        <p>Loading Dashboard...</p>
      </div>
    );
  }

  return (
    <div className="mfg-dashboard-full">
      {/* Sidebar */}
      <aside className={`mfg-sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="mfg-sidebar-header">
          <img src="/logo.jpeg" alt="FabriXaa" className="mfg-logo" onError={(e) => e.target.style.display = 'none'} />
          <h2>FabriXaa</h2>
        </div>

        <nav className="mfg-sidebar-nav">
          <button
            className={`mfg-nav-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => { setActiveTab('overview'); setSidebarOpen(false); }}
          >
            <span>📊</span> <span className="mfg-nav-label">Overview</span>
          </button>
          <button
            className={`mfg-nav-item ${activeTab === 'products' ? 'active' : ''}`}
            onClick={() => { setActiveTab('products'); setSidebarOpen(false); }}
          >
            <span>📦</span> <span className="mfg-nav-label">Products</span>
          </button>
          <button
            className={`mfg-nav-item ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => { setActiveTab('orders'); setSidebarOpen(false); }}
          >
            <span>📋</span> <span className="mfg-nav-label">Orders</span>
          </button>
          <button
            className={`mfg-nav-item ${activeTab === 'messages' ? 'active' : ''}`}
            onClick={() => { setActiveTab('messages'); setSidebarOpen(false); }}
          >
            <span>💬</span> <span className="mfg-nav-label">Messages</span>
          </button>
          <button
            className={`mfg-nav-item ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => { setActiveTab('analytics'); setSidebarOpen(false); }}
          >
            <span>📈</span> <span className="mfg-nav-label">Analytics</span>
          </button>
          <button
            className={`mfg-nav-item ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => { setActiveTab('profile'); setSidebarOpen(false); }}
          >
            <span>👤</span> <span className="mfg-nav-label">Profile</span>
          </button>
        </nav>

        <div className="mfg-sidebar-footer">
          <button onClick={handleLogout} className="mfg-logout-btn">
            <span>🚪</span> <span className="mfg-nav-label">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="mfg-main">
        <header className="mfg-topbar">
          <button
            className="mfg-toggle-sidebar"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            ☰
          </button>
          <h1>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</h1>
          <div className="mfg-profile">
            <div className="mfg-avatar">{user?.name?.charAt(0) || 'M'}</div>
            <div className="mfg-user-info">
              <p className="mfg-name">{user?.name}</p>
              <p className="mfg-email">{user?.email}</p>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="mfg-content">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="mfg-overview">
              <div className="mfg-stats-grid">
                <div className="mfg-stat-card gradient-gold">
                  <span className="mfg-stat-icon">📦</span>
                  <h3>Total Products</h3>
                  <p className="mfg-stat-num">{stats.totalProducts}</p>
                </div>
                <div className="mfg-stat-card gradient-green">
                  <span className="mfg-stat-icon">📋</span>
                  <h3>Total Orders</h3>
                  <p className="mfg-stat-num">{stats.totalOrders}</p>
                </div>
                <div className="mfg-stat-card gradient-teal">
                  <span className="mfg-stat-icon">⏳</span>
                  <h3>Pending Orders</h3>
                  <p className="mfg-stat-num">{stats.pendingOrders}</p>
                </div>
                <div className="mfg-stat-card gradient-nude">
                  <span className="mfg-stat-icon">💰</span>
                  <h3>Total Revenue</h3>
                  <p className="mfg-stat-num">৳{stats.revenue.toLocaleString()}</p>
                </div>
              </div>

              <div className="mfg-info-cards">
                <div className="mfg-info-card">
                  <h4>📅 This Month Revenue</h4>
                  <p>৳{stats.monthlyRevenue.toLocaleString()}</p>
                </div>
                <div className="mfg-info-card">
                  <h4>🎯 This Month Orders</h4>
                  <p>{stats.ordersThisMonth} orders</p>
                </div>
              </div>
            </div>
          )}

          {/* Products Tab */}
          {activeTab === 'products' && (
            <div className="mfg-products">
              <div className="mfg-products-header">
                <h2>My Products ({products.length})</h2>
                <button onClick={handleAddProduct} className="mfg-add-btn">
                  ➕ Add Product
                </button>
              </div>

              <div className="mfg-products-grid">
                {products.map(product => (
                  <div key={product._id} className="mfg-product-card">
                    <div className="mfg-product-image">{product.image}</div>
                    <h3>{product.title}</h3>
                    <div className="mfg-product-details">
                      <p><strong>Quality:</strong> {product.quality}</p>
                      <p><strong>GSM:</strong> {product.gsm}</p>
                      <p><strong>Sizes:</strong> {product.sizes}</p>
                      <p><strong>Price:</strong> ৳{product.minPrice} - ৳{product.maxPrice}</p>
                      <p><strong>Orders:</strong> {product.orders}</p>
                    </div>
                    <div className="mfg-product-actions">
                      <button className="mfg-edit-btn">✏️ Edit</button>
                      <button className="mfg-delete-btn">🗑️ Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Orders Tab */}
          {activeTab === 'orders' && (
            <div className="mfg-orders">
              <h2>Recent Orders ({orders.length})</h2>
              <div className="mfg-orders-table">
                {orders.map(order => (
                  <div key={order._id} className="mfg-order-row">
                    <div className="mfg-order-info">
                      <h4>{order.buyerName}</h4>
                      <p>Qty: {order.quantity}</p>
                    </div>
                    <div className="mfg-order-price">
                      <p>৳{order.price}</p>
                    </div>
                    <div className={`mfg-order-status ${order.status.toLowerCase()}`}>
                      {order.status}
                    </div>
                    <div className="mfg-order-actions">
                      {order.status === 'Pending' && (
                        <>
                          <button className="mfg-approve-btn">✅ Approve</button>
                          <button className="mfg-reject-btn">❌ Reject</button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Messages Tab */}
          {activeTab === 'messages' && (
            <div className="mfg-messages">
              <h2>Messages (Coming Soon)</h2>
              <div className="mfg-coming-soon">
                <p>💬 Real-time messaging feature coming soon!</p>
              </div>
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === 'analytics' && (
            <div className="mfg-analytics">
              <h2>Analytics & Reports</h2>
              <div className="mfg-analytics-grid">
                <div className="mfg-analytics-card">
                  <h3>📊 Monthly Sales</h3>
                  <p>Chart coming soon</p>
                </div>
                <div className="mfg-analytics-card">
                  <h3>📈 Yearly Sales</h3>
                  <p>Chart coming soon</p>
                </div>
              </div>
            </div>
          )}

          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <div className="mfg-profile-section">
              <h2>Profile Information</h2>
              <div className="mfg-profile-card">
                <p><strong>Name:</strong> {user?.name}</p>
                <p><strong>Email:</strong> {user?.email}</p>
                <p><strong>Company:</strong> {user?.companyName}</p>
                <p><strong>Address:</strong> {user?.address}</p>
                <p><strong>Phone:</strong> {user?.phone}</p>
                <p><strong>Status:</strong> {user?.isApproved ? '✅ Approved' : '⏳ Pending'}</p>
              </div>
              <button className="mfg-edit-profile-btn">✏️ Edit Profile</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
