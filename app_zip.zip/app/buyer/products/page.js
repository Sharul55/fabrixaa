'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function BuyerProducts() {
  const router = useRouter();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [filters, setFilters] = useState({
    quality: 'All',
    minPrice: 0,
    maxPrice: 10000
  });

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      router.push('/login');
      return;
    }
    setUser(JSON.parse(userStr));
    fetchProducts();
  }, [router]);

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/products');
      const data = await response.json();
      if (data.success) {
        setProducts(data.products || []);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/');
  };

  if (!user) return <div>লোড হচ্ছে...</div>;

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation */}
      <nav className="bg-blue-600 text-white p-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex gap-6">
            <Link href="/buyer/dashboard" className="hover:text-blue-200">
              🏠 ড্যাশবোর্ড
            </Link>
            <Link href="/buyer/products" className="hover:text-blue-200 font-bold">
              🛍️ পণ্য
            </Link>
            <Link href="/buyer/orders" className="hover:text-blue-200">
              📦 আমার অর্ডার
            </Link>
            <Link href="/buyer/chat" className="hover:text-blue-200">
              💬 চ্যাট
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <span>{user.name}</span>
            <button
              onClick={handleLogout}
              className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded"
            >
              লগআউট
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">🔍 ফিল্টার করুন</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold mb-2">গুণমান</label>
              <select
                value={filters.quality}
                onChange={(e) => setFilters({...filters, quality: e.target.value})}
                className="w-full px-4 py-2 border rounded"
              >
                <option value="All">সব</option>
                <option value="Low">কম (Low)</option>
                <option value="Standard">স্ট্যান্ডার্ড</option>
                <option value="Premium">প্রিমিয়াম</option>
              </select>
            </div>
            <div>
              <label className="block font-bold mb-2">সর্বনিম্ন দাম</label>
              <input
                type="number"
                value={filters.minPrice}
                onChange={(e) => setFilters({...filters, minPrice: parseInt(e.target.value)})}
                className="w-full px-4 py-2 border rounded"
              />
            </div>
            <div>
              <label className="block font-bold mb-2">সর্বোচ্চ দাম</label>
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: parseInt(e.target.value)})}
                className="w-full px-4 py-2 border rounded"
              />
            </div>
          </div>
        </div>

        {/* Products List */}
        {loading ? (
          <div className="text-center py-12">⏳ পণ্য লোড হচ্ছে...</div>
        ) : products.length === 0 ? (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-8 text-center">
            <p className="text-gray-600">কোনো পণ্য পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map(product => (
              <div key={product._id} className="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                {/* Image */}
                <div className="bg-gray-300 h-48 flex items-center justify-center">
                  {product.images && product.images[0] ? (
                    <img src={product.images[0]} alt={product.productName} className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-gray-500">📷 ছবি নেই</span>
                  )}
                </div>

                {/* Product Info */}
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-2">{product.productName}</h3>
                  
                  <p className="text-sm text-gray-600 mb-2">
                    📏 GSM: {product.gsm} | আকার: {product.size?.join(', ')}
                  </p>

                  {/* Qualities */}
                  <div className="mb-3 space-y-1">
                    {product.qualities?.map((q, idx) => (
                      <div key={idx} className="text-sm">
                        <span className="font-bold">{q.quality}:</span> ৳{q.minPrice} - ৳{q.maxPrice}
                      </div>
                    ))}
                  </div>

                  {/* Manufacturer Info */}
                  <div className="bg-blue-50 p-3 rounded mb-3 text-sm">
                    <p className="font-bold">নির্মাতা:</p>
                    <p>{product.manufacturerId?.name}</p>
                    <p className="text-gray-600">{product.manufacturerId?.companyName}</p>
                  </div>

                  {/* Order Button */}
                  <Link href={`/buyer/order/${product._id}`}>
                    <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded transition">
                      🛒 অর্ডার করুন
                    </button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
