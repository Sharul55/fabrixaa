'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function BuyerOrders() {
  const router = useRouter();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      router.push('/login');
      return;
    }
    setUser(JSON.parse(userStr));
    fetchOrders();
  }, [router]);

  const fetchOrders = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/orders?type=buyer', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setOrders(data.orders || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/');
  };

  const getStatusColor = (status) => {
    const colors = {
      'Pending': 'bg-yellow-100 text-yellow-800',
      'Approved': 'bg-blue-100 text-blue-800',
      'Shipped': 'bg-purple-100 text-purple-800',
      'Delivered': 'bg-green-100 text-green-800',
      'Rejected': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (!user) return <div>লোড হচ্ছে...</div>;

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation */}
      <nav className="bg-blue-600 text-white p-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex gap-6">
            <Link href="/buyer/dashboard" className="hover:text-blue-200">
              🏠 ড্যাশবোর্ড
            </Link>
            <Link href="/buyer/products" className="hover:text-blue-200">
              🛍️ পণ্য
            </Link>
            <Link href="/buyer/orders" className="hover:text-blue-200 font-bold">
              📦 আমার অর্ডার
            </Link>
            <Link href="/buyer/chat" className="hover:text-blue-200">
              💬 চ্যাট
            </Link>
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded"
          >
            লগআউট
          </button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">📦 আমার অর্ডার</h1>

        {loading ? (
          <div className="text-center py-12">⏳ লোড হচ্ছে...</div>
        ) : orders.length === 0 ? (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-8 text-center">
            <p className="text-gray-600 mb-4">কোনো অর্ডার নেই</p>
            <Link href="/buyer/products">
              <button className="bg-blue-600 text-white px-6 py-2 rounded">
                🛍️ শপিং করুন
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order._id} className="bg-white rounded-lg shadow p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">অর্ডার ID</p>
                    <p className="font-bold">{order._id.toString().substring(0, 8)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">পরিমাণ</p>
                    <p className="font-bold">{order.quantity} ইউনিট</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">মোট দাম</p>
                    <p className="font-bold text-lg">৳{order.totalPrice}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">স্ট্যাটাস</p>
                    <span className={`inline-block px-3 py-1 rounded ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                {order.status === 'Approved' && (
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-4">
                    <p className="font-bold text-blue-700 mb-2">💳 পেমেন্ট বিস্তারিত:</p>
                    <p className="text-sm"><strong>ব্যাংক:</strong> {order.bankAccount?.bankName}</p>
                    <p className="text-sm"><strong>অ্যাকাউন্ট:</strong> {order.bankAccount?.accountNumber}</p>
                    <p className="text-sm"><strong>নাম:</strong> {order.bankAccount?.accountHolder}</p>
                  </div>
                )}

                {order.paymentStatus === 'Paid' && (
                  <div className="bg-green-50 border-l-4 border-green-500 p-4">
                    <p className="text-green-700">✅ পেমেন্ট সম্পন্ন</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
