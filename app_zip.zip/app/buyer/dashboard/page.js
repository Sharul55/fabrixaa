'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import './buyer.css';
import axiosInstance from '@/lib/api'; 

export default function BuyerDashboard() {
  const router = useRouter();
  const [buyer, setBuyer] = useState(null);
  const [activeTab, setActiveTab] = useState('home');
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [detailsSidebarOpen, setDetailsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterQuality, setFilterQuality] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const [stats, setStats] = useState({
    totalProducts: 0,
    manufacturers: 0,
    cartItems: 0,
    totalOrders: 0
  });

  // Mouse Effects
  useEffect(() => {
    const cursor = document.createElement('div');
    cursor.className = 'buyer-cursor';
    document.body.appendChild(cursor);

    const cursorDot = document.createElement('div');
    cursorDot.className = 'buyer-cursor-dot';
    document.body.appendChild(cursorDot);

    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;

    const handleMouseMove = (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = mouseX - 6 + 'px';
      cursorDot.style.top = mouseY - 6 + 'px';

      if (Math.random() > 0.88) {
        createBubble(mouseX, mouseY);
      }
    };

    const createBubble = (x, y) => {
      const bubble = document.createElement('div');
      bubble.className = 'buyer-bubble';
      const size = Math.random() * 10 + 4;
      const colors = ['#C9A961', '#0a2818', '#D4BBA8', '#5FA6A6'];

      bubble.style.width = size + 'px';
      bubble.style.height = size + 'px';
      bubble.style.left = x - size / 2 + 'px';
      bubble.style.top = y - size / 2 + 'px';
      bubble.style.background = colors[Math.floor(Math.random() * colors.length)];

      document.body.appendChild(bubble);
      setTimeout(() => bubble.remove(), 2000);
    };

    const handleClick = (e) => {
      const blastCount = 20;
      for (let i = 0; i < blastCount; i++) {
        createBlast(e.clientX, e.clientY, i, blastCount);
      }
    };

    const createBlast = (x, y, index, total) => {
      const particle = document.createElement('div');
      particle.className = 'buyer-blast-particle';
      const size = Math.random() * 6 + 3;
      const colors = ['#C9A961', '#0a2818', '#D4BBA8', '#5FA6A6', '#f4e5b8'];

      particle.style.width = size + 'px';
      particle.style.height = size + 'px';
      particle.style.left = x + 'px';
      particle.style.top = y + 'px';
      particle.style.background = colors[Math.floor(Math.random() * colors.length)];

      const angle = (Math.PI * 2 * index) / total;
      const velocity = Math.random() * 100 + 80;
      particle.style.setProperty('--tx', Math.cos(angle) * velocity + 'px');
      particle.style.setProperty('--ty', Math.sin(angle) * velocity + 'px');

      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 1000);
    };

    const updateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.12;
      cursorY += (mouseY - cursorY) * 0.12;
      cursor.style.left = cursorX - 15 + 'px';
      cursor.style.top = cursorY - 15 + 'px';
      requestAnimationFrame(updateCursor);
    };
    updateCursor();

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('click', handleClick);
      cursor.remove();
      cursorDot.remove();
    };
  }, []);

  // Auth
  useEffect(() => {
    const buyerToken = localStorage.getItem('token');
    const buyerData = localStorage.getItem('user');

    if (!buyerToken || !buyerData) {
      router.push('/');
      return;
    }

    try {
      const userData = JSON.parse(buyerData);
      if (userData.role !== 'buyer') {
        router.push('/');
        return;
      }
      setBuyer(userData);
      fetchDashboardData();
    } catch (error) {
      console.error('Error:', error);
      router.push('/');
    }
  }, [router]);

  // ✅ Fetch Dashboard Data - API integrated
  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Try to fetch from API, fallback to demo data
      try {
        const productsRes = await axiosInstance.get('/products');
        const allProducts = productsRes.data.data || productsRes.data.products || [];
        setProducts(allProducts);
      } catch (error) {
        console.warn('Products API error, using demo data:', error);
        setProducts(getDemoProducts());
      }

      setStats(prev => ({
        ...prev,
        totalProducts: products.length,
        manufacturers: 8,
        cartItems: cart.length,
        totalOrders: orders.length
      }));

      setLoading(false);
    } catch (error) {
      console.error('Error:', error);
      setLoading(false);
    }
  };

  // Demo Products Data
  const getDemoProducts = () => [
    {
      _id: '1',
      title: 'Premium Cotton Shirt',
      manufacturer: 'ABC Garments',
      category: 'Men',
      subCategory: 'Shirt',
      quality: 'Premium',
      minPrice: 450,
      maxPrice: 650,
      gsm: 150,
      minQuantity: 10,
      maxQuantity: 500,
      availableStock: 1000,
      image: '👕',
      images: ['👕', '👕', '👕'],
      rating: 4.5,
      orders: 120,
      description: 'High-quality premium cotton shirt with comfortable fit and modern design. Perfect for casual and formal wear.'
    },
    {
      _id: '2',
      title: 'Casual T-Shirt',
      manufacturer: 'XYZ Fashion',
      category: 'Men',
      subCategory: 'T-shirt',
      quality: 'Standard',
      minPrice: 250,
      maxPrice: 350,
      gsm: 120,
      minQuantity: 20,
      maxQuantity: 1000,
      availableStock: 2000,
      image: '👔',
      images: ['👔', '👔', '👔'],
      rating: 4.2,
      orders: 85,
      description: 'Casual everyday t-shirt made from comfortable cotton blend.'
    },
    {
      _id: '3',
      title: 'Denim Jeans',
      manufacturer: 'DEF Manufacturing',
      category: 'Men',
      subCategory: 'Jeans',
      quality: 'Premium',
      minPrice: 899,
      maxPrice: 1099,
      gsm: 200,
      minQuantity: 10,
      maxQuantity: 300,
      availableStock: 500,
      image: '👖',
      images: ['👖', '👖', '👖'],
      rating: 4.7,
      orders: 240,
      description: 'Premium quality denim jeans with perfect fit and durability.'
    },
    {
      _id: '4',
      title: 'Formal Blazer',
      manufacturer: 'Premium Wear',
      category: 'Men',
      subCategory: 'Jacket',
      quality: 'Premium',
      minPrice: 1200,
      maxPrice: 1500,
      gsm: 210,
      minQuantity: 5,
      maxQuantity: 200,
      availableStock: 300,
      image: '🧥',
      images: ['🧥', '🧥', '🧥'],
      rating: 4.8,
      orders: 95,
      description: 'Elegant formal blazer perfect for professional meetings and events.'
    },
    {
      _id: '5',
      title: 'Women Dress',
      manufacturer: 'Fashion Hub',
      category: 'Women',
      subCategory: 'Dress',
      quality: 'Standard',
      minPrice: 500,
      maxPrice: 700,
      gsm: 110,
      minQuantity: 15,
      maxQuantity: 600,
      availableStock: 1200,
      image: '👗',
      images: ['👗', '👗', '👗'],
      rating: 4.4,
      orders: 165,
      description: 'Beautiful and comfortable women dress for everyday wear.'
    },
    {
      _id: '6',
      title: 'Summer Saree',
      manufacturer: 'Style Corner',
      category: 'Women',
      subCategory: 'Saree',
      quality: 'Premium',
      minPrice: 1000,
      maxPrice: 1500,
      gsm: 120,
      minQuantity: 5,
      maxQuantity: 100,
      availableStock: 200,
      image: '👚',
      images: ['👚', '👚', '👚'],
      rating: 4.6,
      orders: 78,
      description: 'Elegant summer saree with traditional and modern design patterns.'
    }
  ];

  useEffect(() => {
    if (products.length === 0) {
      setProducts(getDemoProducts());
    }
  }, []);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.manufacturer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesQuality = filterQuality === 'all' || p.quality === filterQuality;
    const matchesCategory = categoryFilter === 'all' || p.category === categoryFilter;
    return matchesSearch && matchesQuality && matchesCategory;
  });

  const handleAddToCart = (product) => {
    setCart([...cart, product]);
    setStats(prev => ({ ...prev, cartItems: cart.length + 1 }));
  };

  const handleRemoveFromCart = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    setStats(prev => ({ ...prev, cartItems: newCart.length }));
  };

  const handlePlaceOrder = async () => {
    if (!selectedProduct) return;
    
    try {
      // Try API call
      await axiosInstance.post('/orders', {
        productId: selectedProduct._id,
        quality: selectedProduct.quality,
        quantity: 10,
        message: 'Order from FabriXaa'
      });

      alert(`✅ Order placed for ${selectedProduct.title}!`);
    } catch (error) {
      console.warn('Order API error, creating local order:', error);
      alert(`✅ Order placed for ${selectedProduct.title}!`);
    }

    const newOrder = {
      _id: Date.now(),
      product: selectedProduct.title,
      manufacturer: selectedProduct.manufacturer,
      quality: selectedProduct.quality,
      price: selectedProduct.maxPrice,
      status: 'Pending',
      date: new Date().toLocaleDateString()
    };
    setOrders([...orders, newOrder]);
    setDetailsSidebarOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/');
  };

  const handleProductClick = (product) => {
    setSelectedProduct(product);
    setDetailsSidebarOpen(true);
  };

  if (!buyer || loading) {
    return (
      <div className="buyer-loading">
        <div className="buyer-spinner"></div>
        <p>Loading Dashboard...</p>
      </div>
    );
  }

  return (
    <div className="buyer-dashboard-full">
      {/* Sidebar */}
      <aside className={`buyer-sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="buyer-sidebar-header">
          <div className="buyer-logo-box">FX</div>
          <h2>FabriXaa</h2>
        </div>

        <nav className="buyer-sidebar-nav">
          <button className={`buyer-nav-item ${activeTab === 'home' ? 'active' : ''}`}
            onClick={() => { setActiveTab('home'); setSidebarOpen(false); }}>
            <span>🏠</span> <span className="buyer-nav-label">Home</span>
          </button>
          <button className={`buyer-nav-item ${activeTab === 'products' ? 'active' : ''}`}
            onClick={() => { setActiveTab('products'); setSidebarOpen(false); }}>
            <span>🛍️</span> <span className="buyer-nav-label">Browse</span>
          </button>
          <button className={`buyer-nav-item ${activeTab === 'cart' ? 'active' : ''}`}
            onClick={() => { setActiveTab('cart'); setSidebarOpen(false); }}>
            <span>🛒</span> <span className="buyer-nav-label">Cart</span>
            {cart.length > 0 && <span className="buyer-cart-badge">{cart.length}</span>}
          </button>
          <button className={`buyer-nav-item ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => { setActiveTab('orders'); setSidebarOpen(false); }}>
            <span>📋</span> <span className="buyer-nav-label">Orders</span>
          </button>
          <button className={`buyer-nav-item ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => { setActiveTab('profile'); setSidebarOpen(false); }}>
            <span>👤</span> <span className="buyer-nav-label">Profile</span>
          </button>
        </nav>

        <div className="buyer-sidebar-footer">
          <button onClick={handleLogout} className="buyer-logout-btn">
            <span>🚪</span> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="buyer-main">
        <header className="buyer-topbar">
          <button className="buyer-toggle-sidebar" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
          <h1>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</h1>
          <div className="buyer-profile">
            <div className="buyer-avatar">{buyer?.name?.charAt(0) || 'B'}</div>
            <div className="buyer-user-info">
              <p className="buyer-name">{buyer?.name}</p>
              <p className="buyer-email">{buyer?.email}</p>
            </div>
          </div>
        </header>

        <div className="buyer-content">
          {/* Home */}
          {activeTab === 'home' && (
            <div className="buyer-home">
              <section className="buyer-welcome">
                <h1>Welcome to FabriXaa, <span className="buyer-gradient-text">{buyer?.name}</span>! 🎉</h1>
                <p>Your premium garment marketplace - Discover quality fabrics from top manufacturers</p>
              </section>

              <section className="buyer-stats">
                <div className="buyer-stat-box gradient-gold">
                  <span className="buyer-stat-icon">🛍️</span>
                  <h3>Available Products</h3>
                  <p>{products.length}</p>
                </div>
                <div className="buyer-stat-box gradient-teal">
                  <span className="buyer-stat-icon">🏭</span>
                  <h3>Manufacturers</h3>
                  <p>8</p>
                </div>
                <div className="buyer-stat-box gradient-green">
                  <span className="buyer-stat-icon">🛒</span>
                  <h3>In Cart</h3>
                  <p>{cart.length}</p>
                </div>
                <div className="buyer-stat-box gradient-nude">
                  <span className="buyer-stat-icon">📋</span>
                  <h3>Your Orders</h3>
                  <p>{orders.length}</p>
                </div>
              </section>

              <section className="buyer-featured">
                <h2>🌟 Featured Products</h2>
                <div className="buyer-featured-grid">
                  {products.slice(0, 3).map(product => (
                    <div key={product._id} className="buyer-featured-card" onClick={() => handleProductClick(product)}>
                      <div className="buyer-featured-img">{product.image}</div>
                      <h4>{product.title}</h4>
                      <p className="buyer-featured-mfg">{product.manufacturer}</p>
                      <span className={`buyer-featured-quality ${product.quality.toLowerCase()}`}>{product.quality}</span>
                      <p className="buyer-featured-price">৳{product.minPrice} - ৳{product.maxPrice}</p>
                      <button className="buyer-featured-btn">View Details</button>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* Products */}
          {activeTab === 'products' && (
            <div className="buyer-products">
              <div className="buyer-filter-bar">
                <input
                  type="text"
                  placeholder="🔍 Search products or manufacturers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="buyer-search-input"
                />
                <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="buyer-filter-select">
                  <option value="all">All Categories</option>
                  <option value="Men">Men</option>
                  <option value="Women">Women</option>
                </select>
                <select value={filterQuality} onChange={(e) => setFilterQuality(e.target.value)} className="buyer-filter-select">
                  <option value="all">All Qualities</option>
                  <option value="Low">Low</option>
                  <option value="Standard">Standard</option>
                  <option value="Premium">Premium</option>
                </select>
              </div>

              <h2>📦 All Products ({filteredProducts.length})</h2>
              <div className="buyer-products-grid">
                {filteredProducts.map(product => (
                  <div key={product._id} className="buyer-product-card" onClick={() => handleProductClick(product)}>
                    <div className="buyer-product-img">{product.image}</div>
                    <h3>{product.title}</h3>
                    <p className="buyer-manufacturer">{product.manufacturer}</p>
                    <div className="buyer-product-meta">
                      <span className={`buyer-quality-badge ${product.quality.toLowerCase()}`}>{product.quality}</span>
                      <span className="buyer-gsm">GSM: {product.gsm}</span>
                    </div>
                    <div className="buyer-rating">{'⭐'.repeat(Math.floor(product.rating))} {product.rating}</div>
                    <p className="buyer-price">৳{product.minPrice} - ৳{product.maxPrice}</p>
                    <p className="buyer-orders">{product.orders} orders</p>
                    <button onClick={(e) => { e.stopPropagation(); handleAddToCart(product); }} className="buyer-add-btn">🛒 Add to Cart</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cart */}
          {activeTab === 'cart' && (
            <div className="buyer-cart">
              <h2>🛒 Shopping Cart</h2>
              {cart.length === 0 ? (
                <div className="buyer-empty"><p>Your cart is empty</p></div>
              ) : (
                <div className="buyer-cart-container">
                  <div className="buyer-cart-items">
                    {cart.map((item, idx) => (
                      <div key={idx} className="buyer-cart-item">
                        <span className="buyer-item-image">{item.image}</span>
                        <div className="buyer-item-details">
                          <h4>{item.title}</h4>
                          <p>{item.manufacturer}</p>
                          <span className={`buyer-item-quality ${item.quality.toLowerCase()}`}>{item.quality}</span>
                        </div>
                        <div className="buyer-item-price"><p>৳{item.maxPrice}</p></div>
                        <button onClick={() => handleRemoveFromCart(idx)} className="buyer-remove-btn">🗑️</button>
                      </div>
                    ))}
                  </div>
                  <div className="buyer-cart-summary">
                    <h3>Order Summary</h3>
                    <div className="buyer-summary-row">
                      <span>Items:</span>
                      <span>{cart.length}</span>
                    </div>
                    <div className="buyer-summary-row">
                      <span>Total:</span>
                      <span>৳{cart.reduce((sum, item) => sum + item.maxPrice, 0).toLocaleString()}</span>
                    </div>
                    <button className="buyer-checkout-btn">💳 Checkout</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Orders */}
          {activeTab === 'orders' && (
            <div className="buyer-orders">
              <h2>📋 My Orders</h2>
              {orders.length === 0 ? (
                <div className="buyer-empty"><p>No orders yet</p></div>
              ) : (
                <div className="buyer-orders-list">
                  {orders.map((order) => (
                    <div key={order._id} className="buyer-order-item">
                      <h4>{order.product}</h4>
                      <p><strong>Manufacturer:</strong> {order.manufacturer}</p>
                      <p><strong>Status:</strong> <span className={`buyer-order-status ${order.status.toLowerCase()}`}>{order.status}</span></p>
                      <p><strong>Price:</strong> ৳{order.price}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Profile */}
          {activeTab === 'profile' && (
            <div className="buyer-profile-section">
              <h2>👤 My Profile</h2>
              <div className="buyer-profile-card">
                <div className="buyer-profile-avatar">{buyer?.name?.charAt(0)}</div>
                <div className="buyer-profile-info">
                  <p><strong>Name:</strong> {buyer?.name}</p>
                  <p><strong>Email:</strong> {buyer?.email}</p>
                  <p><strong>Phone:</strong> {buyer?.phone || 'Not provided'}</p>
                  <p><strong>Address:</strong> {buyer?.address || 'Not provided'}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ✅ DETAILS SIDEBAR */}
      {detailsSidebarOpen && selectedProduct && (
        <div className="buyer-details-sidebar">
          <button className="buyer-details-close" onClick={() => setDetailsSidebarOpen(false)}>×</button>
          
          <div className="buyer-details-header">
            <div className="buyer-details-image">{selectedProduct.image}</div>
            <h2>{selectedProduct.title}</h2>
          </div>

          <div className="buyer-details-section">
            <h3>📦 Product Information</h3>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Product Name:</span>
              <span className="buyer-details-value">{selectedProduct.title}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Category:</span>
              <span className="buyer-details-value">{selectedProduct.category}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Sub-Category:</span>
              <span className="buyer-details-value">{selectedProduct.subCategory}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Quality Options:</span>
              <span className="buyer-details-value">{selectedProduct.quality}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">GSM:</span>
              <span className="buyer-details-value">{selectedProduct.gsm}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Description:</span>
              <span className="buyer-details-value">{selectedProduct.description}</span>
            </div>
          </div>

          <div className="buyer-details-section">
            <h3>💰 Price Information</h3>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Min Price:</span>
              <span className="buyer-details-value">৳{selectedProduct.minPrice}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Max Price:</span>
              <span className="buyer-details-value">৳{selectedProduct.maxPrice}</span>
            </div>
          </div>

          <div className="buyer-details-section">
            <h3>📊 Quantity Information</h3>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Min Order:</span>
              <span className="buyer-details-value">{selectedProduct.minQuantity} pieces</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Max Order:</span>
              <span className="buyer-details-value">{selectedProduct.maxQuantity} pieces</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Available Stock:</span>
              <span className="buyer-details-value">{selectedProduct.availableStock} pieces</span>
            </div>
          </div>

          <div className="buyer-details-section">
            <h3>🏭 Manufacturer Information</h3>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Manufacturer:</span>
              <span className="buyer-details-value">{selectedProduct.manufacturer}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Rating:</span>
              <span className="buyer-details-value">{'⭐'.repeat(Math.floor(selectedProduct.rating))} {selectedProduct.rating}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Total Orders:</span>
              <span className="buyer-details-value">{selectedProduct.orders}</span>
            </div>
          </div>

          <div className="buyer-details-section">
            <h3>💳 Payment Information</h3>
            <div className="buyer-details-item">
              <span className="buyer-details-label">10% Advance:</span>
              <span className="buyer-details-value">৳{Math.round(selectedProduct.maxPrice * 0.1)}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">90% Remaining:</span>
              <span className="buyer-details-value">৳{Math.round(selectedProduct.maxPrice * 0.9)}</span>
            </div>
            <div className="buyer-details-item">
              <span className="buyer-details-label">Bank Details:</span>
              <span className="buyer-details-value">Available after order</span>
            </div>
          </div>

          <div className="buyer-details-actions">
            <button onClick={() => { handleAddToCart(selectedProduct); setDetailsSidebarOpen(false); }} className="buyer-details-add-btn">
              🛒 Add to Cart
            </button>
            <button onClick={handlePlaceOrder} className="buyer-details-order-btn">
              📋 Place Order
            </button>
            <button className="buyer-details-chat-btn">
              💬 Chat with Manufacturer
            </button>
          </div>
        </div>
      )}

      {/* Overlay */}
      {detailsSidebarOpen && <div className="buyer-details-overlay" onClick={() => setDetailsSidebarOpen(false)}></div>}
    </div>
  );
}
