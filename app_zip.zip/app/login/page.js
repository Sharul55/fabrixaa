'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Validation
      if (!formData.email || !formData.password) {
        setError('ইমেইল এবং পাসওয়ার্ড প্রয়োজন');
        setLoading(false);
        return;
      }

      // API Call
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'লগইন ব্যর্থ');
        setLoading(false);
        return;
      }

      // Success
      console.log('✓ লগইন সফল:', data);
      
      // Token এবং User সংরক্ষণ করুন
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));

      alert('স্বাগতম, ' + data.user.name + '!');

      // Dashboard এ রিডাইরেক্ট করুন
      if (data.user.role === 'buyer') {
        router.push('/buyer/dashboard');
      } else if (data.user.role === 'manufacturer') {
        router.push('/manufacturer/dashboard');
      } else if (data.user.role === 'admin') {
        router.push('/admin/dashboard');
      }

    } catch (err) {
      console.error('Error:', err);
      setError('সার্ভার ত্রুটি: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold text-center mb-2 text-gray-800">
          লগইন করুন
        </h1>
        <p className="text-center text-gray-600 mb-6">FabriXaa এ স্বাগতম</p>

        {/* Error Message */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            ❌ {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">ইমেইল *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="example@gmail.com"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">পাসওয়ার্ড *</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="আপনার পাসওয়ার্ড"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg transition duration-300"
          >
            {loading ? '⏳ লগইন করছি...' : '✓ লগইন করুন'}
          </button>
        </form>

        {/* Register Link */}
        <p className="text-center text-gray-600 mt-6">
          নতুন ব্যবহারকারী?{' '}
          <Link href="/register" className="text-blue-600 hover:underline font-bold">
            এখানে তৈরি করুন
          </Link>
        </p>

        <p className="text-center text-gray-500 text-sm mt-4">
          Test Credentials:
          <br />
          📧 alam@gmail.com
          <br />
          🔑 Pass@123
        </p>
      </div>
    </div>
  );
}
