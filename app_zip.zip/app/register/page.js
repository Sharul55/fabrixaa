'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function RegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [userType, setUserType] = useState('buyer'); // buyer or manufacturer

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    companyName: '',
    address: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Validation
      if (!formData.name || !formData.email || !formData.password || !formData.phone) {
        setError('সব তথ্য প্রয়োজন');
        setLoading(false);
        return;
      }

      if (!formData.email.endsWith('@gmail.com')) {
        setError('শুধুমাত্র @gmail.com ইমেইল গ্রহণযোগ্য');
        setLoading(false);
        return;
      }

      if (formData.password.length < 6) {
        setError('পাসওয়ার্ড কমপক্ষে ৬ ক্যারেক্টার হতে হবে');
        setLoading(false);
        return;
      }

      if (userType === 'manufacturer' && (!formData.companyName || !formData.address)) {
        setError('কোম্পানির নাম এবং ঠিকানা প্রয়োজন');
        setLoading(false);
        return;
      }

      // API Call
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          role: userType
        })
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'নিবন্ধন ব্যর্থ');
        setLoading(false);
        return;
      }

      // Success
      console.log('✓ নিবন্ধন সফল:', data);
      
      // Token save করুন
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));

      // Success message
      alert(data.message);

      // Dashboard এ রিডাইরেক্ট করুন
      if (userType === 'buyer') {
        router.push('/buyer/dashboard');
      } else {
        router.push('/manufacturer/dashboard');
      }

    } catch (err) {
      console.error('Error:', err);
      setError('সার্ভার ত্রুটি: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold text-center mb-2 text-gray-800">
          নতুন অ্যাকাউন্ট
        </h1>
        <p className="text-center text-gray-600 mb-6">FabriXaa এ যোগ দিন</p>

        {/* User Type Selection */}
        <div className="flex gap-4 mb-6">
          <label className="flex items-center cursor-pointer">
            <input
              type="radio"
              name="userType"
              value="buyer"
              checked={userType === 'buyer'}
              onChange={(e) => setUserType(e.target.value)}
              className="mr-2"
            />
            <span className="text-gray-700">ক্রেতা</span>
          </label>
          <label className="flex items-center cursor-pointer">
            <input
              type="radio"
              name="userType"
              value="manufacturer"
              checked={userType === 'manufacturer'}
              onChange={(e) => setUserType(e.target.value)}
              className="mr-2"
            />
            <span className="text-gray-700">নির্মাতা</span>
          </label>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            ❌ {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">নাম *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="আপনার নাম"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">ইমেইল *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="example@gmail.com"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">পাসওয়ার্ড *</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="কমপক্ষে ৬ ক্যারেক্টার"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Phone */}
          <div>
            <label className="block text-gray-700 font-bold mb-2">ফোন নম্বর *</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="01712345678"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Manufacturer Fields */}
          {userType === 'manufacturer' && (
            <>
              <div>
                <label className="block text-gray-700 font-bold mb-2">কোম্পানির নাম *</label>
                <input
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  placeholder="আপনার কোম্পানির নাম"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-2">ঠিকানা *</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="ঢাকা, বাংলাদেশ"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg transition duration-300"
          >
            {loading ? '⏳ পাঠাচ্ছি...' : '✓ অ্যাকাউন্ট তৈরি করুন'}
          </button>
        </form>

        {/* Login Link */}
        <p className="text-center text-gray-600 mt-6">
          ইতিমধ্যে অ্যাকাউন্ট আছে?{' '}
          <Link href="/login" className="text-blue-600 hover:underline font-bold">
            লগইন করুন
          </Link>
        </p>
      </div>
    </div>
  );
}
