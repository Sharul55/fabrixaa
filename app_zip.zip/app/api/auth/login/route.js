import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export async function POST(req) {
  try {
    await connectDB();

    const { email, password } = await req.json();

    // User খুঁজুন
    const user = await User.findOne({ email });

    if (!user) {
      return Response.json({
        success: false,
        message: 'User not found'
      }, { status: 401 });
    }

    // Password verify করুন
    const isPasswordMatch = await bcrypt.compare(password, user.password);

    if (!isPasswordMatch) {
      return Response.json({
        success: false,
        message: 'Invalid password'
      }, { status: 401 });
    }

    // ✅ IMPORTANT: Manufacturer এর জন্য isApproved check শুধু info দেওয়ার জন্য
    if (user.role === 'manufacturer' && !user.isApproved) {
      return Response.json({
        success: true,  // ✅ True রাখুন - user approve pending
        message: 'Your account is pending admin approval. You can login but features are limited.',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          isApproved: user.isApproved
        },
        token: null  // ❌ Token দিবেন না
      }, { status: 200 });
    }

    // Token generate করুন
    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );

    console.log(`✅ Login successful: ${email}`);

    return Response.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isApproved: user.isApproved
      }
    });

  } catch (error) {
    console.error('❌ Login error:', error);
    return Response.json({
      success: false,
      message: error.message || 'Login failed'
    }, { status: 500 });
  }
}
