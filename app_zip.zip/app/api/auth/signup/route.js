import { connectDB } from '@/lib/mongodb.js'; 
import User from '@/lib/models/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export async function POST(req) {
  try {
    // Database connect করুন
    await connectDB();

    const { name, email, password, role, companyName, phone, country, address } = await req.json();

    // Email already exist check করুন
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return Response.json({ 
        success: false, 
        message: 'Email already registered' 
      }, { status: 400 });
    }

    // Password hash করুন
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // নতুন User তৈরি করুন
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      role,
      companyName,
      phone,
      country,
      address,
      isApproved: role === 'buyer' ? true : false  // Buyers সাথে সাথে approve
    });

    await newUser.save();

    // Token generate করুন
    const token = jwt.sign(
      { id: newUser._id, email: newUser.email, role: newUser.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );

    // ✅ Count automatically বাড়বে!
    console.log(`✅ New ${role} registered: ${email}`);

    return Response.json({
      success: true,
      message: 'User registered successfully',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        isApproved: newUser.isApproved
      }
    });

  } catch (error) {
    console.error('❌ Signup error:', error);
    return Response.json({ 
      success: false, 
      message: error.message || 'Signup failed' 
    }, { status: 500 });
  }
}
