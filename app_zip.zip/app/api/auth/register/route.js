import { connectDB } from '@/lib/mongoose.js';
import User from '@/models/User.js';
import bcrypt from 'bcryptjs';
import { generateToken } from '@/lib/jwt.js';
import { NextResponse } from 'next/server';

export async function POST(req) {
  try {
    await connectDB();

    const { name, email, password, phone, companyName, address, role } = await req.json();

    // Validation
    if (!name || !email || !password || !phone) {
      return NextResponse.json(
        { error: 'সব তথ্য প্রয়োজন' },
        { status: 400 }
      );
    }

    // Email validation
    if (!email.endsWith('@gmail.com')) {
      return NextResponse.json(
        { error: 'শুধুমাত্র @gmail.com ইমেইল গ্রহণযোগ্য' },
        { status: 400 }
      );
    }

    // Duplicate check
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return NextResponse.json(
        { error: 'এই ইমেইল ইতিমধ্যে নিবন্ধিত' },
        { status: 400 }
      );
    }

    // Password hash
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = new User({
      name,
      email,
      password: hashedPassword,
      phone,
      role: role || 'buyer',
      companyName: role === 'manufacturer' ? companyName : undefined,
      address: role === 'manufacturer' ? address : undefined,
      verified: role === 'buyer', // Buyer সরাসরি verified
      blocked: false
    });

    await user.save();

    // Token generate করুন
    const token = generateToken(user._id, user.role);

    return NextResponse.json({
      success: true,
      message: role === 'manufacturer' 
        ? 'নিবন্ধন সফল, অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন'
        : 'নিবন্ধন সফল!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        verified: user.verified
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
