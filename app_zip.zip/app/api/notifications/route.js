import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Notification from '@/models/Notification';
import { NextResponse } from 'next/server';

export async function GET(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user) {
      return NextResponse.json({ error: 'অননুমোদিত' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const unreadOnly = searchParams.get('unreadOnly') === 'true';

    let query = { userId: user._id };
    
    if (unreadOnly) {
      query.read = false;
    }

    const notifications = await Notification.find(query)
      .sort({ createdAt: -1 })
      .limit(50)
      .exec();

    const unreadCount = await Notification.countDocuments({
      userId: user._id,
      read: false
    });

    return NextResponse.json({
      success: true,
      notifications,
      unreadCount
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

export async function PATCH(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user) {
      return NextResponse.json({ error: 'অননুমোদিত' }, { status: 401 });
    }

    const { notificationId } = await req.json();

    const notification = await Notification.findByIdAndUpdate(
      notificationId,
      { read: true },
      { new: true }
    );

    return NextResponse.json({
      success: true,
      message: 'Notification পড়া হয়েছে',
      notification
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
