import { Server } from 'socket.io';
import { NextResponse } from 'next/server';

const io = new Server({
  cors: {
    origin: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000',
    methods: ['GET', 'POST']
  }
});

// Connected users track করার জন্য
const connectedUsers = new Map(); // userId -> socketId

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get('action');

  // Socket connection handle
  if (!io.httpServer) {
    // এটি initialization এর সময় চলে
    console.log('Socket.io initialized');
  }

  return NextResponse.json({ 
    status: 'Socket.io server running',
    connectedUsers: connectedUsers.size 
  });
}

// Socket event handlers
if (typeof io !== 'undefined') {
  io.on('connection', (socket) => {
    console.log('✓ নতুন user connected:', socket.id);

    // User যখন join করে
    socket.on('user_connected', (userId) => {
      connectedUsers.set(userId, socket.id);
      console.log(`✓ ${userId} connected`);
      
      // সবাইকে বলুন কে অনলাইন আছে
      io.emit('user_online', { userId, socketId: socket.id });
    });

    // চ্যাট মেসেজ পাঠানো
    socket.on('send_message', (data) => {
      const { senderId, receiverId, message, roomId } = data;
      
      // Receiver কে মেসেজ পাঠান
      if (connectedUsers.has(receiverId)) {
        const receiverSocketId = connectedUsers.get(receiverId);
        io.to(receiverSocketId).emit('receive_message', {
          senderId,
          receiverId,
          message,
          roomId,
          timestamp: new Date()
        });
      }
    });

    // Order notification Manufacturer কে
    socket.on('order_created', (data) => {
      const { manufacturerId, buyerId, productName, quantity, totalPrice } = data;
      
      if (connectedUsers.has(manufacturerId)) {
        const manufacturerSocketId = connectedUsers.get(manufacturerId);
        io.to(manufacturerSocketId).emit('new_order', {
          buyerId,
          productName,
          quantity,
          totalPrice,
          timestamp: new Date(),
          message: 'নতুন অর্ডার এসেছে!'
        });
      }
    });

    // Order approved Buyer কে
    socket.on('order_approved', (data) => {
      const { buyerId, manufacturerId, bankAccount, bankName, totalPrice } = data;
      
      if (connectedUsers.has(buyerId)) {
        const buyerSocketId = connectedUsers.get(buyerId);
        io.to(buyerSocketId).emit('order_confirmed', {
          manufacturerId,
          bankAccount,
          bankName,
          totalPrice,
          timestamp: new Date(),
          message: 'আপনার অর্ডার অনুমোদিত হয়েছে!'
        });
      }
    });

    // Payment notification Admin কে
    socket.on('payment_received', (data) => {
      const { adminId, orderId, amount, buyerId, manufacturerId, bankName } = data;
      
      if (connectedUsers.has(adminId)) {
        const adminSocketId = connectedUsers.get(adminId);
        io.to(adminSocketId).emit('payment_notification', {
          orderId,
          amount,
          buyerId,
          manufacturerId,
          bankName,
          commission: amount * 0.05, // ৫% কমিশন
          timestamp: new Date(),
          message: 'পেমেন্ট এসেছে!'
        });
      }
    });

    // Disconnect
    socket.on('disconnect', () => {
      for (let [userId, socketId] of connectedUsers.entries()) {
        if (socketId === socket.id) {
          connectedUsers.delete(userId);
          io.emit('user_offline', { userId });
          console.log(`✗ ${userId} disconnected`);
          break;
        }
      }
    });
  });
}

export { io };
