import { connectDB } from '@/lib/mongodb.js'; 
import Product from '@/lib/models/Product.js';
import jwt from 'jsonwebtoken';

export async function POST(req) {
  try {
    // Database connect করুন
    await connectDB();

    // Token verify করুন
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return Response.json({ 
        success: false, 
        message: 'No authorization token' 
      }, { status: 401 });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.role !== 'manufacturer') {
      return Response.json({ 
        success: false, 
        message: 'Only manufacturers can upload products' 
      }, { status: 403 });
    }

    const { title, description, price, quantity, category, images } = await req.json();

    // নতুন Product তৈরি করুন
    const newProduct = new Product({
      title,
      description,
      manufacturerId: decoded.id,
      price,
      quantity,
      category,
      images: images || []
    });

    await newProduct.save();

    // ✅ Product count automatically বাড়বে!
    console.log(`✅ New product uploaded: ${title}`);

    return Response.json({
      success: true,
      message: 'Product uploaded successfully',
      product: newProduct
    });

  } catch (error) {
    console.error('❌ Upload error:', error);
    return Response.json({ 
      success: false, 
      message: error.message || 'Upload failed' 
    }, { status: 500 });
  }
}
