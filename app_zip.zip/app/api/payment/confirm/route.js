import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Order from '@/models/Order';
import Commission from '@/models/Commission';
import Notification from '@/models/Notification';
import User from '@/models/User';
import { NextResponse } from 'next/server';
import { io } from '@/app/api/socket/route';

export async function POST(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user || user.role !== 'buyer') {
      return NextResponse.json(
        { error: 'শুধুমাত্র Buyer পেমেন্ট করতে পারে' },
        { status: 403 }
      );
    }

    const { orderId } = await req.json();

    const order = await Order.findById(orderId);
    if (!order) {
      return NextResponse.json(
        { error: 'অর্ডার পাওয়া যায়নি' },
        { status: 404 }
      );
    }

    // পেমেন্ট স্ট্যাটাস আপডেট করুন
    order.paymentStatus = 'Paid';
    order.status = 'Shipped';

    await order.save();

    // কমিশন গণনা করুন
    const commissionAmount = order.totalPrice * 0.05; // ৫%
    const commission = new Commission({
      orderId: order._id,
      totalAmount: order.totalPrice,
      commissionPercentage: 5,
      commissionAmount,
      month: new Date().toISOString().slice(0, 7), // "2025-11"
      year: new Date().getFullYear()
    });

    await commission.save();

    // Admin পান (একটি নির্দিষ্ট admin ID ধরে)
    const admin = await User.findOne({ role: 'admin' });

    if (admin) {
      // Admin কে Notification পাঠান
      const adminNotification = new Notification({
        userId: admin._id,
        type: 'payment_received',
        title: 'পেমেন্ট পেয়েছেন',
        description: `অর্ডার #${order._id} এর জন্য ৳${order.totalPrice} পেমেন্ট পেয়েছেন। কমিশন: ৳${commissionAmount}`,
        relatedData: {
          orderId: order._id,
          amount: order.totalPrice,
          commission: commissionAmount,
          buyerId: order.buyerId,
          manufacturerId: order.manufacturerId,
          bankName: order.bankAccount?.bankName
        }
      });

      await adminNotification.save();

      // Socket.io দিয়ে Real-time notification
      if (io) {
        io.emit('payment_received', {
          adminId: admin._id.toString(),
          orderId: order._id.toString(),
          amount: order.totalPrice,
          commission: commissionAmount,
          buyerId: order.buyerId.toString(),
          manufacturerId: order.manufacturerId.toString(),
          bankName: order.bankAccount?.bankName
        });
      }
    }

    return NextResponse.json({
      success: true,
      message: 'পেমেন্ট নিশ্চিত করা হয়েছে',
      order,
      commission
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
