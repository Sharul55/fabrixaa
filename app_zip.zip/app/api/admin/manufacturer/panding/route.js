import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

export async function DELETE(req, { params }) {
  try {
    await connectDB();

    // ✅ IMPORTANT: await params (Next.js 15)
    const { id } = await params;

    console.log('❌ Deleting manufacturer ID:', id);

    if (!id || id.length !== 24) {
      return Response.json({
        success: false,
        message: 'Invalid manufacturer ID'
      }, { status: 400 });
    }

    const manufacturer = await User.findByIdAndDelete(id);

    if (!manufacturer) {
      return Response.json({
        success: false,
        message: 'Manufacturer not found'
      }, { status: 404 });
    }

    console.log('✅ Deleted successfully:', manufacturer.email);

    return Response.json({
      success: true,
      message: 'Manufacturer deleted successfully'
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
