import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

export async function PUT(req, { params }) {
  try {
    await connectDB();

    // ✅ IMPORTANT: await params (Next.js 15)
    const { id } = await params;

    console.log('✅ Approving manufacturer ID:', id);

    if (!id || id.length !== 24) {
      return Response.json({
        success: false,
        message: 'Invalid manufacturer ID'
      }, { status: 400 });
    }

    const manufacturer = await User.findByIdAndUpdate(
      id,
      { isApproved: true },
      { new: true }
    );

    if (!manufacturer) {
      return Response.json({
        success: false,
        message: 'Manufacturer not found'
      }, { status: 404 });
    }

    console.log('✅ Approved successfully:', manufacturer.email);

    return Response.json({
      success: true,
      message: 'Manufacturer approved successfully',
      data: manufacturer
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
