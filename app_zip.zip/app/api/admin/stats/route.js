import { connectDB } from '@/lib/mongoose.js';
import { authenticate } from '@/lib/auth.js';
import { isAdmin } from '@/lib/auth.js';
import User from '@/models/User.js';
import Order from '@/models/Order.js';
import Commission from '@/models/Commission.js';
import { NextResponse } from 'next/server';

export async function GET(req) {
  try {
    await connectDB();

    const user = await authenticate(req);
    if (!user || !isAdmin(user)) {
      return NextResponse.json(
        { error: 'শুধুমাত্র Admin এ অ্যাক্সেস' },
        { status: 403 }
      );
    }

    // সব ব্যবহারকারী
    const totalUsers = await User.countDocuments();

    // সব অর্ডার
    const totalOrders = await Order.countDocuments();

    // মোট কমিশন
    const commissions = await Commission.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: '$commissionAmount' }
        }
      }
    ]);
    const totalCommission = commissions[0]?.total || 0;

    // অপেক্ষমাণ Manufacturer
    const pendingManufacturers = await User.countDocuments({
      role: 'manufacturer',
      verified: false
    });

    return NextResponse.json({
      success: true,
      stats: {
        totalUsers,
        totalOrders,
        totalCommission: Math.round(totalCommission),
        pendingManufacturers
      }
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
