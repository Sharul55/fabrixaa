import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

// ✅ GET - Pending manufacturers
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action');

    await connectDB();

    // Pending manufacturers আনুন
    if (action === 'pending') {
      const pending = await User.find({
        role: 'manufacturer',
        isApproved: false
      }).lean();

      return Response.json({
        success: true,
        data: pending
      });
    }

    // সব manufacturers
    const allMfg = await User.find({
      role: 'manufacturer'
    }).lean();

    return Response.json({
      success: true,
      data: allMfg
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}

// ✅ PUT - Approve manufacturer
export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    const action = searchParams.get('action');

    await connectDB();

    if (action === 'approve' && id) {
      const manufacturer = await User.findByIdAndUpdate(
        id,
        { isApproved: true },
        { new: true }
      );

      if (!manufacturer) {
        return Response.json({
          success: false,
          message: 'Manufacturer not found'
        }, { status: 404 });
      }

      return Response.json({
        success: true,
        message: 'Approved successfully',
        data: manufacturer
      });
    }

    return Response.json({
      success: false,
      message: 'Invalid action'
    }, { status: 400 });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}

// ✅ DELETE - Reject manufacturer
export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    await connectDB();

    if (!id) {
      return Response.json({
        success: false,
        message: 'ID required'
      }, { status: 400 });
    }

    const manufacturer = await User.findByIdAndDelete(id);

    if (!manufacturer) {
      return Response.json({
        success: false,
        message: 'Manufacturer not found'
      }, { status: 404 });
    }

    return Response.json({
      success: true,
      message: 'Deleted successfully'
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
