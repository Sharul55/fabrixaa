import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

export async function GET(req) {
  try {
    await connectDB();

    const pending = await User.find({
      role: 'manufacturer',
      isApproved: false
    }).lean();

    console.log('✅ Found pending manufacturers:', pending.length);
    console.log('📊 Sample data:', pending[0]); // First one এর structure দেখুন

    return Response.json({
      success: true,
      data: pending
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
