'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AdminVerify() {
  const router = useRouter();
  const [manufacturers, setManufacturers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      router.push('/login');
      return;
    }
    const userData = JSON.parse(userStr);
    if (userData.role !== 'admin') {
      router.push('/');
      return;
    }
    setUser(userData);
    fetchPendingManufacturers();
  }, [router]);

  const fetchPendingManufacturers = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/admin/pending-manufacturers', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (data.success) {
        setManufacturers(data.manufacturers || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (manufacturerId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/admin/verify/${manufacturerId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ action: 'approve' })
      });
      const data = await response.json();
      if (data.success) {
        alert('✅ অনুমোদিত হয়েছে');
        fetchPendingManufacturers();
      }
    } catch (error) {
      alert('❌ ত্রুটি: ' + error.message);
    }
  };

  const handleReject = async (manufacturerId) => {
    if (!confirm('সত্যিই প্রত্যাখ্যান করবেন?')) return;
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/admin/verify/${manufacturerId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ action: 'reject' })
      });
      const data = await response.json();
      if (data.success) {
        alert('❌ প্রত্যাখ্যান করা হয়েছে');
        fetchPendingManufacturers();
      }
    } catch (error) {
      alert('ত্রুটি: ' + error.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/');
  };

  if (!user) return <div>লোড হচ্ছে...</div>;

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation */}
      <nav className="bg-red-600 text-white p-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex gap-6">
            <Link href="/admin/dashboard" className="hover:text-red-200">
              📊 ড্যাশবোর্ড
            </Link>
            <Link href="/admin/users" className="hover:text-red-200">
              👥 ব্যবহারকারী
            </Link>
            <Link href="/admin/verify" className="hover:text-red-200 font-bold">
              ✓ যাচাইকরণ
            </Link>
            <Link href="/admin/commission" className="hover:text-red-200">
              💰 কমিশন
            </Link>
          </div>
          <button
            onClick={handleLogout}
            className="bg-yellow-500 hover:bg-yellow-600 px-4 py-2 rounded"
          >
            লগআউট
          </button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">✅ Manufacturer যাচাইকরণ</h1>

        {loading ? (
          <div className="text-center py-12">⏳ লোড হচ্ছে...</div>
        ) : manufacturers.length === 0 ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
            <p className="text-gray-600">সব অনুমোদিত! 🎉</p>
          </div>
        ) : (
          <div className="space-y-4">
            {manufacturers.map(mfg => (
              <div key={mfg._id} className="bg-white rounded-lg shadow p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">নাম</p>
                    <p className="font-bold text-lg">{mfg.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">ইমেইল</p>
                    <p className="font-mono text-sm">{mfg.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">কোম্পানি</p>
                    <p className="font-bold">{mfg.companyName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">ফোন</p>
                    <p className="font-mono">{mfg.phone}</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded mb-4">
                  <p className="text-sm text-gray-600">ঠিকানা</p>
                  <p>{mfg.address}</p>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => handleApprove(mfg._id)}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded"
                  >
                    ✅ অনুমোদন করুন
                  </button>
                  <button
                    onClick={() => handleReject(mfg._id)}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2 rounded"
                  >
                    ❌ প্রত্যাখ্যান করুন
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
