import { connectDB } from '@/lib/mongoose.js';
import { authenticate } from '@/lib/auth.js';
import { isAdmin } from '@/lib/auth.js';
import User from '@/models/User.js';
import { NextResponse } from 'next/server';

export async function POST(req, { params }) {
  try {
    await connectDB();

    const user = await authenticate(req);
    if (!user || !isAdmin(user)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const { id } = params;
    const { action } = await req.json();

    const manufacturer = await User.findById(id);
    if (!manufacturer || manufacturer.role !== 'manufacturer') {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    if (action === 'approve') {
      manufacturer.verified = true;
    } else if (action === 'reject') {
      manufacturer.blocked = true;
    }

    await manufacturer.save();

    return NextResponse.json({
      success: true,
      message: action === 'approve' ? 'অনুমোদিত' : 'প্রত্যাখ্যান করা হয়েছে'
    });

  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
