import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Chat from '@/models/Chat';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user) {
      return NextResponse.json({ error: 'অননুমোদিত' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const receiverId = searchParams.get('receiverId');
    const limit = parseInt(searchParams.get('limit')) || 50;

    if (!receiverId) {
      return NextResponse.json(
        { error: 'Receiver ID প্রয়োজন' },
        { status: 400 }
      );
    }

    // Room ID তৈরি করুন
    const roomId = [user._id, receiverId].sort().join('_');

    // চ্যাট হিস্টরি ফেচ করুন (সর্বশেষ ৫০টি)
    const chats = await Chat.find({ roomId })
      .sort({ createdAt: -1 })
      .limit(limit)
      .exec();

    return NextResponse.json({
      success: true,
      roomId,
      chats: chats.reverse() // প্রথমটি আগে আসবে
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
