import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Chat from '@/models/Chat';
import Notification from '@/models/Notification';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user) {
      return NextResponse.json({ error: 'অননুমোদিত' }, { status: 401 });
    }

    const { receiverId, message } = await req.json();

    if (!receiverId || !message) {
      return NextResponse.json(
        { error: 'সব তথ্য প্রয়োজন' },
        { status: 400 }
      );
    }

    // Room ID তৈরি করুন (দুটি ID এর সংমিশ্রণ)
    const roomId = [user._id, receiverId].sort().join('_');

    // চ্যাট সংরক্ষণ করুন
    const chat = new Chat({
      senderId: user._id,
      receiverId,
      roomId,
      message
    });

    await chat.save();

    // Notification তৈরি করুন
    const notification = new Notification({
      userId: receiverId,
      type: 'new_message',
      title: `${user.name} থেকে নতুন বার্তা`,
      description: message.substring(0, 50) + '...',
      relatedData: {
        senderName: user.name,
        senderId: user._id
      }
    });

    await notification.save();

    return NextResponse.json({
      success: true,
      message: 'বার্তা পাঠানো হয়েছে',
      chat
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
