import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Order from '@/models/Order';
import Notification from '@/models/Notification';
import User from '@/models/User';
import { NextResponse } from 'next/server';
import { io } from '@/app/api/socket/route';

export async function POST(req, { params }) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user || user.role !== 'manufacturer') {
      return NextResponse.json(
        { error: 'শুধুমাত্র Manufacturer অনুমোদন করতে পারে' },
        { status: 403 }
      );
    }

    const { id } = params;
    const { bankAccount, bankName, accountHolder } = await req.json();

    const order = await Order.findById(id);
    if (!order) {
      return NextResponse.json(
        { error: 'অর্ডার পাওয়া যায়নি' },
        { status: 404 }
      );
    }

    // অর্ডার অনুমোদন করুন
    order.status = 'Approved';
    order.bankAccount = {
      accountNumber: bankAccount,
      bankName,
      accountHolder
    };

    await order.save();

    // Buyer কে Notification পাঠান
    const buyerNotification = new Notification({
      userId: order.buyerId,
      type: 'order_approved',
      title: 'আপনার অর্ডার অনুমোদিত হয়েছে',
      description: `আপনার অর্ডার অনুমোদিত। পেমেন্ট বিস্তারিত নীচে দেওয়া আছে।`,
      relatedData: {
        orderId: order._id,
        manufacturerId: user._id,
        bankAccount,
        bankName,
        amount: order.totalPrice
      }
    });

    await buyerNotification.save();

    // Socket.io দিয়ে Real-time notification
    if (io) {
      io.emit('order_approved', {
        buyerId: order.buyerId.toString(),
        manufacturerId: user._id.toString(),
        bankAccount,
        bankName,
        totalPrice: order.totalPrice,
        orderId: order._id.toString()
      });
    }

    return NextResponse.json({
      success: true,
      message: 'অর্ডার অনুমোদিত হয়েছে',
      order
    });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
