import { connectDB } from '@/lib/mongoose';
import { authenticate } from '@/lib/auth';
import Order from '@/models/Order';
import Notification from '@/models/Notification';
import Product from '@/models/Product';
import { NextRequest, NextResponse } from 'next/server';
import { io } from '@/app/api/socket/route';

export async function POST(req) {
  try {
    await connectDB();
    
    const user = await authenticate(req);
    if (!user || user.role !== 'buyer') {
      return NextResponse.json(
        { error: 'শুধুমাত্র Buyer অর্ডার করতে পারে' },
        { status: 403 }
      );
    }

    const { productId, manufacturerId, quantity, selectedQuality } = await req.json();

    // পণ্য খুঁজুন
    const product = await Product.findById(productId);
    if (!product) {
      return NextResponse.json(
        { error: 'পণ্য পাওয়া যায়নি' },
        { status: 404 }
      );
    }

    // গুণমান অনুযায়ী দাম পান
    const qualityData = product.qualities.find(q => q.quality === selectedQuality);
    if (!qualityData) {
      return NextResponse.json(
        { error: 'এই গুণমান উপলব্ধ নয়' },
        { status: 400 }
      );
    }

    const pricePerUnit = (qualityData.minPrice + qualityData.maxPrice) / 2;
    const totalPrice = pricePerUnit * quantity;

    // অর্ডার তৈরি করুন
    const order = new Order({
      buyerId: user._id,
      manufacturerId,
      productId,
      quantity,
      selectedQuality,
      pricePerUnit,
      totalPrice,
      status: 'Pending'
    });

    await order.save();

    // Manufacturer কে Notification পাঠান
    const manufacturerNotification = new Notification({
      userId: manufacturerId,
      type: 'order_received',
      title: 'নতুন অর্ডার পেয়েছেন',
      description: `${product.productName} এর ${quantity} ইউনিট অর্ডার - ৳${totalPrice}`,
      relatedData: {
        orderId: order._id,
        buyerId: user._id,
        productName: product.productName,
        quantity,
        amount: totalPrice
      }
    });

    await manufacturerNotification.save();

    // Socket.io দিয়ে Real-time notification পাঠান
    if (io) {
      io.emit('order_created', {
        manufacturerId: manufacturerId.toString(),
        buyerId: user._id.toString(),
        productName: product.productName,
        quantity,
        totalPrice,
        orderId: order._id.toString()
      });
    }

    return NextResponse.json({
      success: true,
      message: 'অর্ডার তৈরি হয়েছে',
      order
    }, { status: 201 });

  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
