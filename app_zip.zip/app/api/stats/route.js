import { connectDB } from '@/lib/mongodb.js'; 
import User from '@/lib/models/User.js';
import Product from '@/lib/models/Product.js';
import Commission from '@/models/Commission.js';

export async function GET(req) {
  try {
    // Database connect করুন
    await connectDB();

    // Real-time count করুন database থেকে
    const manufacturersCount = await User.countDocuments({ 
      role: 'manufacturer',
      isApproved: true  // শুধু approved manufacturers
    });

    const buyersCount = await User.countDocuments({ 
      role: 'buyer'
    });

    const productsCount = await Product.countDocuments();

    // দেশের সংখ্যা - এখনকে hardcoded (পরে আপডেট করব)
    const countriesCount = 25;

    console.log(`📊 Stats - Manufacturers: ${manufacturersCount}, Buyers: ${buyersCount}, Products: ${productsCount}`);

    return Response.json({
      success: true,
      data: {
        manufacturers: manufacturersCount,
        buyers: buyersCount,
        products: productsCount,
        countries: countriesCount
      }
    });

  } catch (error) {
    console.error('❌ Stats fetch error:', error);
    
    // Fallback - যদি কোনো error হয়
    return Response.json({
      success: true,
      data: {
        manufacturers: 0,
        buyers: 0,
        products: 0,
        countries: 25
      }
    });
  }
}
