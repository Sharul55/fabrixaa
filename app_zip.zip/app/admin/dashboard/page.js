'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axiosInstance from '@/lib/api';
import './admin.css';

export default function AdminDashboard() {
  const router = useRouter();
  const [admin, setAdmin] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalManufacturers: 0,
    totalBuyers: 0,
    pendingApprovals: 0,
    blockedUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    platformCommission: 0
  });

  const [users, setUsers] = useState([]);
  const [pendingManufacturers, setPendingManufacturers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);

  // Premium Mouse Effects
  useEffect(() => {
    const cursor = document.createElement('div');
    cursor.className = 'admin-cursor';
    document.body.appendChild(cursor);

    const cursorDot = document.createElement('div');
    cursorDot.className = 'admin-cursor-dot';
    document.body.appendChild(cursorDot);

    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;

    const handleMouseMove = (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = mouseX - 6 + 'px';
      cursorDot.style.top = mouseY - 6 + 'px';

      if (Math.random() > 0.85) {
        createBubble(mouseX, mouseY);
      }
    };

    const createBubble = (x, y) => {
      const bubble = document.createElement('div');
      bubble.className = 'admin-bubble';
      const size = Math.random() * 10 + 4;
      const colors = ['#C9A961', '#0c3b2e', '#D4BBA8', '#5FA6A6'];

      bubble.style.width = size + 'px';
      bubble.style.height = size + 'px';
      bubble.style.left = x - size / 2 + 'px';
      bubble.style.top = y - size / 2 + 'px';
      bubble.style.background = colors[Math.floor(Math.random() * colors.length)];

      document.body.appendChild(bubble);
      setTimeout(() => bubble.remove(), 2000);
    };

    const handleClick = (e) => {
      const blastCount = 20;
      for (let i = 0; i < blastCount; i++) {
        createBlast(e.clientX, e.clientY, i, blastCount);
      }
    };

    const createBlast = (x, y, index, total) => {
      const particle = document.createElement('div');
      particle.className = 'admin-blast-particle';
      const size = Math.random() * 6 + 3;
      const colors = ['#C9A961', '#0c3b2e', '#D4BBA8', '#5FA6A6', '#f4e5b8'];

      particle.style.width = size + 'px';
      particle.style.height = size + 'px';
      particle.style.left = x + 'px';
      particle.style.top = y + 'px';
      particle.style.background = colors[Math.floor(Math.random() * colors.length)];

      const angle = (Math.PI * 2 * index) / total;
      const velocity = Math.random() * 100 + 80;
      particle.style.setProperty('--tx', Math.cos(angle) * velocity + 'px');
      particle.style.setProperty('--ty', Math.sin(angle) * velocity + 'px');

      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 1000);
    };

    const updateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.12;
      cursorY += (mouseY - cursorY) * 0.12;
      cursor.style.left = cursorX - 15 + 'px';
      cursor.style.top = cursorY - 15 + 'px';
      requestAnimationFrame(updateCursor);
    };
    updateCursor();

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('click', handleClick);
      cursor.remove();
      cursorDot.remove();
    };
  }, []);

  // Check Auth
  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    const adminData = localStorage.getItem('admin');

    if (!adminToken || !adminData) {
      router.push('/admin/login');
      return;
    }

    try {
      const parsedAdmin = JSON.parse(adminData);
      setAdmin(parsedAdmin);
      fetchDashboardData();
    } catch (error) {
      console.error('Error:', error);
      router.push('/admin/login');
    }
  }, [router]);

  // ✅ Fetch Dashboard Data
  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Demo data - আপনার API থেকে fetch করতে পারেন
      const demoUsers = [
        { _id: '1', name: 'ABC Garments', email: 'info@abc.com', role: 'manufacturer', companyName: 'ABC Garments', address: 'Dhaka, BD', status: 'verified' },
        { _id: '2', name: 'John Buyer', email: 'john@example.com', role: 'buyer', status: 'active' },
        { _id: '3', name: 'XYZ Fashion', email: 'xyz@fashion.com', role: 'manufacturer', companyName: 'XYZ Fashion', address: 'Chittagong, BD', status: 'pending' }
      ];

      const manufacturers = demoUsers.filter(u => u.role === 'manufacturer');
      const buyers = demoUsers.filter(u => u.role === 'buyer');
      const pendingApprovals = manufacturers.filter(m => m.status === 'pending');

      setAllUsers(demoUsers);
      setPendingManufacturers(pendingApprovals);

      setStats({
        totalUsers: demoUsers.length,
        totalManufacturers: manufacturers.length,
        totalBuyers: buyers.length,
        pendingApprovals: pendingApprovals.length,
        blockedUsers: 0,
        totalProducts: 28,
        totalOrders: 145,
        platformCommission: 87500
      });

      setLoading(false);
    } catch (error) {
      console.error('❌ Error fetching data:', error);
      setLoading(false);
    }
  };

  // ✅ Approve Manufacturer
  const handleApproveManufacturer = async (userId) => {
    try {
      // API call করুন (demo এ direct update করছি)
      alert('✅ Manufacturer approved successfully!');
      
      setPendingManufacturers(prev => prev.filter(m => m._id !== userId));
      
      setStats(prev => ({
        ...prev,
        pendingApprovals: Math.max(0, prev.pendingApprovals - 1)
      }));
    } catch (error) {
      console.error('Error approving manufacturer:', error);
      alert('❌ Error approving manufacturer');
    }
  };

  // ✅ Reject Manufacturer
  const handleRejectManufacturer = async (userId) => {
    if (!window.confirm('Are you sure you want to reject this manufacturer?')) {
      return;
    }

    try {
      alert('❌ Manufacturer rejected and removed!');
      
      setPendingManufacturers(prev => prev.filter(m => m._id !== userId));
      
      setStats(prev => ({
        ...prev,
        pendingApprovals: Math.max(0, prev.pendingApprovals - 1),
        totalManufacturers: Math.max(0, prev.totalManufacturers - 1),
        totalUsers: Math.max(0, prev.totalUsers - 1)
      }));
    } catch (error) {
      console.error('Error rejecting manufacturer:', error);
      alert('❌ Error rejecting manufacturer');
    }
  };

  // ✅ Block/Unblock User
  const handleBlockUser = async (userId, currentStatus) => {
    try {
      const newStatus = currentStatus === 'blocked' ? 'active' : 'blocked';
      alert(`✅ User ${newStatus === 'blocked' ? 'blocked' : 'unblocked'} successfully!`);
      
      setAllUsers(prev => prev.map(u => 
        u._id === userId ? { ...u, status: newStatus } : u
      ));
    } catch (error) {
      console.error('Error updating user:', error);
      alert('❌ Error updating user');
    }
  };

  // ✅ Delete User
  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) {
      return;
    }

    try {
      alert('✅ User deleted successfully!');
      setAllUsers(prev => prev.filter(u => u._id !== userId));
      
      setStats(prev => ({
        ...prev,
        totalUsers: Math.max(0, prev.totalUsers - 1)
      }));
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('❌ Error deleting user');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('admin');
    router.push('/admin/login');
  };

  if (!admin || loading) {
    return (
      <div className="admin-loading">
        <div className="admin-spinner"></div>
        <p>Loading Dashboard...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <div className="admin-sidebar-header">
          <div className="admin-logo-box">FX</div>
          <h2>FabriXaa Admin</h2>
        </div>

        <nav className="admin-nav">
          <button 
            className={`admin-nav-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <span>📊</span> Overview
          </button>
          <button 
            className={`admin-nav-item ${activeTab === 'approvals' ? 'active' : ''}`}
            onClick={() => setActiveTab('approvals')}
          >
            <span>✅</span> Approvals
            {stats.pendingApprovals > 0 && <span className="admin-badge">{stats.pendingApprovals}</span>}
          </button>
          <button 
            className={`admin-nav-item ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            <span>👥</span> Users
          </button>
          <button 
            className={`admin-nav-item ${activeTab === 'products' ? 'active' : ''}`}
            onClick={() => setActiveTab('products')}
          >
            <span>📦</span> Products
          </button>
          <button 
            className={`admin-nav-item ${activeTab === 'revenue' ? 'active' : ''}`}
            onClick={() => setActiveTab('revenue')}
          >
            <span>💰</span> Revenue
          </button>
        </nav>

        <div className="admin-sidebar-footer">
          <button onClick={handleLogout} className="admin-logout-btn">
            <span>🚪</span> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        <header className="admin-topbar">
          <h1>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</h1>
          <div className="admin-profile">
            <div className="admin-avatar">{admin?.name?.charAt(0) || 'A'}</div>
            <div className="admin-info">
              <p className="admin-name">{admin?.name || 'Admin'}</p>
              <p className="admin-email">{admin?.email}</p>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="admin-content">
          {/* Overview */}
          {activeTab === 'overview' && (
            <div className="admin-overview">
              <div className="admin-stats-grid">
                <div className="admin-stat-card gradient-gold">
                  <span className="admin-stat-icon">👥</span>
                  <h3>Total Users</h3>
                  <p className="admin-stat-num">{stats.totalUsers}</p>
                </div>
                <div className="admin-stat-card gradient-green">
                  <span className="admin-stat-icon">🏭</span>
                  <h3>Manufacturers</h3>
                  <p className="admin-stat-num">{stats.totalManufacturers}</p>
                </div>
                <div className="admin-stat-card gradient-teal">
                  <span className="admin-stat-icon">🛍️</span>
                  <h3>Buyers</h3>
                  <p className="admin-stat-num">{stats.totalBuyers}</p>
                </div>
                <div className="admin-stat-card gradient-nude">
                  <span className="admin-stat-icon">📦</span>
                  <h3>Products</h3>
                  <p className="admin-stat-num">{stats.totalProducts}</p>
                </div>
              </div>

              <div className="admin-info-cards">
                <div className="admin-info-card">
                  <h4>⏳ Pending Approvals</h4>
                  <p className="admin-info-value">{stats.pendingApprovals}</p>
                </div>
                <div className="admin-info-card">
                  <h4>📋 Total Orders</h4>
                  <p className="admin-info-value">{stats.totalOrders}</p>
                </div>
                <div className="admin-info-card">
                  <h4>💰 Platform Commission</h4>
                  <p className="admin-info-value">৳{stats.platformCommission.toLocaleString()}</p>
                </div>
                <div className="admin-info-card">
                  <h4>🚫 Blocked Users</h4>
                  <p className="admin-info-value">{stats.blockedUsers}</p>
                </div>
              </div>
            </div>
          )}

          {/* Approvals */}
          {activeTab === 'approvals' && (
            <div className="admin-approvals">
              <h2>Pending Manufacturer Approvals ({pendingManufacturers.length})</h2>
              {pendingManufacturers.length === 0 ? (
                <div className="admin-empty">
                  <p>✅ No pending approvals</p>
                </div>
              ) : (
                <div className="admin-cards">
                  {pendingManufacturers.map(mfg => (
                    <div key={mfg._id} className="admin-card">
                      <div className="admin-card-info">
                        <div className="admin-card-avatar">{mfg.name?.charAt(0) || 'M'}</div>
                        <div>
                          <h4>{mfg.name}</h4>
                          <p>{mfg.email}</p>
                          <p className="admin-company">{mfg.companyName}</p>
                          <p className="admin-address">📍 {mfg.address}</p>
                        </div>
                      </div>
                      <div className="admin-card-actions">
                        <button onClick={() => handleApproveManufacturer(mfg._id)} className="admin-approve">
                          ✅ Approve
                        </button>
                        <button onClick={() => handleRejectManufacturer(mfg._id)} className="admin-reject">
                          ❌ Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Users */}
          {activeTab === 'users' && (
            <div className="admin-users">
              <h2>All Users ({stats.totalUsers})</h2>
              {allUsers.length === 0 ? (
                <div className="admin-empty">
                  <p>👥 No users found</p>
                </div>
              ) : (
                <div className="admin-users-table">
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allUsers.map(user => (
                        <tr key={user._id}>
                          <td>{user.name}</td>
                          <td>{user.email}</td>
                          <td className="admin-role">{user.role}</td>
                          <td><span className={`admin-status ${user.status}`}>{user.status}</span></td>
                          <td className="admin-actions">
                            <button 
                              onClick={() => handleBlockUser(user._id, user.status)}
                              className={`admin-btn ${user.status === 'blocked' ? 'unblock' : 'block'}`}
                            >
                              {user.status === 'blocked' ? '🔓 Unblock' : '🔒 Block'}
                            </button>
                            <button 
                              onClick={() => handleDeleteUser(user._id)}
                              className="admin-btn delete"
                            >
                              🗑️ Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Products */}
          {activeTab === 'products' && (
            <div className="admin-products">
              <h2>All Products ({stats.totalProducts})</h2>
              <div className="admin-empty">
                <p>📦 Total products: {stats.totalProducts}</p>
                <p style={{fontSize: '0.9rem', marginTop: '0.5rem'}}>Product management dashboard coming soon</p>
              </div>
            </div>
          )}

          {/* Revenue */}
          {activeTab === 'revenue' && (
            <div className="admin-revenue">
              <div className="admin-revenue-card">
                <h2>Platform Commission</h2>
                <p className="admin-revenue-amount">৳{stats.platformCommission.toLocaleString()}</p>
                <p className="admin-revenue-note">5% from each completed sale</p>
              </div>
              <div className="admin-revenue-details">
                <h3>Revenue Breakdown</h3>
                <div className="admin-revenue-item">
                  <span>Total Orders:</span>
                  <span>{stats.totalOrders}</span>
                </div>
                <div className="admin-revenue-item">
                  <span>Commission Rate:</span>
                  <span>5%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
