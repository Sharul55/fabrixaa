import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

export async function GET(req) {
  try {
    await connectDB();

    const pendingManufacturers = await User.find({
      role: 'manufacturer',
      isApproved: false
    });

    console.log('✅ Pending Manufacturers:', pendingManufacturers);

    return Response.json({
      success: true,
      data: pendingManufacturers
    });
  } catch (error) {
    console.error('Error:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
