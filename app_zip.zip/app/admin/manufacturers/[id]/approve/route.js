import { connectDB } from '@/lib/mongodb.js';
import User from '@/lib/models/User.js';

export async function PUT(req, { params }) {
  try {
    await connectDB();

    const { id } = params;

    console.log('✅ Approving manufacturer ID:', id); // Debug

    // MongoDB ID check করুন
    if (!id || id.length !== 24) {
      console.log('❌ Invalid ID format:', id);
      return Response.json({
        success: false,
        message: 'Invalid manufacturer ID'
      }, { status: 400 });
    }

    // Update করুন
    const manufacturer = await User.findByIdAndUpdate(
      id,
      { isApproved: true },
      { new: true }
    );

    if (!manufacturer) {
      console.log('❌ Manufacturer not found for ID:', id);
      return Response.json({
        success: false,
        message: 'Manufacturer not found'
      }, { status: 404 });
    }

    console.log('✅ Approved successfully:', manufacturer.email);

    return Response.json({
      success: true,
      message: 'Manufacturer approved successfully',
      data: manufacturer
    });

  } catch (error) {
    console.error('❌ Error approving:', error);
    return Response.json({
      success: false,
      message: error.message
    }, { status: 500 });
  }
}
