'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import './admin-login.css';

export default function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Admin credentials (কঠিন করুন production এ!)
      const ADMIN_EMAIL = 'admin@fabrixaa.com';
      const ADMIN_PASSWORD = 'FabriXaa@2025';

      if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
        // ✅ Login successful
        localStorage.setItem('adminToken', 'admin_token_' + Date.now());
        localStorage.setItem('admin', JSON.stringify({
          name: 'Admin',
          email: ADMIN_EMAIL
        }));

        router.push('/admin/dashboard');
      } else {
        setError('❌ Invalid email or password');
      }
    } catch (err) {
      setError('Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-login-container">
      <div className="admin-login-box">
        <h1>FabriXaa Admin</h1>
        <p>Secure Admin Portal</p>

        {error && <div className="admin-error">{error}</div>}

        <form onSubmit={handleLogin}>
          <div className="admin-form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@fabrixaa.com"
              required
            />
          </div>

          <div className="admin-form-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>

          <button type="submit" disabled={loading} className="admin-login-btn">
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <p className="admin-footer-note">
          For demo: admin@fabrixaa.com / FabriXaa@2025
        </p>
      </div>
    </div>
  );
}
